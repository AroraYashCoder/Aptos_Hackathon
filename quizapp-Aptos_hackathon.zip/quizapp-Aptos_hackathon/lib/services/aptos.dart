import 'dart:convert';
import 'package:http/http.dart' as http;

class AptosService {
  final String nodeUrl = 'https://fullnode.testnet.aptoslabs.com/v1';

  // Fetch account info using the Aptos JSON RPC
  Future<Map<String, dynamic>> getAccountInfo(String address) async {
    final url = Uri.parse('$nodeUrl/accounts/$address');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch account info');
    }
  }

  // Send Aptos tokens using a pre-signed transaction
  Future<String> distributeRewards({
    required String senderKey,
    required String receiverAddr,
    required int rewardAmt,
  }) async {
    final senderAddress = await getAddressFromPrivateKey(senderKey);

    // Prepare the transaction payload with correct types
    final payload = {
      'type': 'entry_function_payload',
      'function': '0x1::coin::transfer',
      'arguments': [
        receiverAddr,
        rewardAmt.toString() // Ensure this is passed as a string
      ],
      'type_arguments': [
        '0x1::aptos_coin::AptosCoin'
      ], // Type argument for AptosCoin
    };

    final txnRequest = await generateTransaction(
      senderAddr: senderAddress,
      privateKey: senderKey,
      payload: payload,
    );

    final response = await submitTransaction(txnRequest);
    return response['hash'];
  }

  // Generate transaction with the sender's private key
  Future<Map<String, dynamic>> generateTransaction({
    required String senderAddr,
    required String privateKey,
    required Map<String, dynamic> payload,
  }) async {
    final accountInfo = await getAccountInfo(senderAddr);
    final sequenceNumber = int.parse(accountInfo['sequence_number']);

    return {
      'sender': senderAddr,
      'sequence_number': sequenceNumber,
      'payload': payload,
      'max_gas_amount': '100000', // Increased gas amount for testing
      'gas_unit_price': '100', // Adjusted gas unit price for testing
      'expiration_timestamp_secs':
          (DateTime.now().millisecondsSinceEpoch ~/ 1000) + 600,
    };
  }

  // Submit the transaction using the Aptos API
  Future<Map<String, dynamic>> submitTransaction(
      Map<String, dynamic> transaction) async {
    final url = Uri.parse('$nodeUrl/transactions');

    final headers = {
      'Content-Type':
          'application/x.aptos.signed_transaction+bcs', // Correct Content-Type
    };

    // Log the transaction for debugging
    print('Transaction body: ${jsonEncode(transaction)}');

    // Send the transaction directly in JSON format
    final response =
        await http.post(url, headers: headers, body: jsonEncode(transaction));

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 202) {
      return jsonDecode(response.body);
    } else {
      throw Exception(
          'Transaction submission failed with status: ${response.statusCode}');
    }
  }

  // Mock function to derive address from the private key
  Future<String> getAddressFromPrivateKey(String privateKey) async {
    // This is just a mock; replace it with actual key derivation logic.
    return '0x306c242f9a09ed4c6c07688e14a2e1504ee043c31d8740b116d037dd17c82261';
  }
}
